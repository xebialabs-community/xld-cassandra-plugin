cassandra % docker build -t cassandra:latest .
docker run -p 22:22 cassandra:lastest
